import presentation.GuestBookUI;

public class Main {

    public static void main(String[] args) {
        GuestBookUI ui = new GuestBookUI();
        ui.start();
    }
}
